const adminID = 604247733
const botID = "donidev_bot"
const channelID = "@pixel_verse"

module.exports = {adminID, botID, channelID}