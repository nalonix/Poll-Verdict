//firebase
const {app, db} = require('./firebase.js')

//firebase functions 
const {collection,query, doc ,getDoc, getDocs,addDoc, setDoc, updateDoc, deleteDoc, orderBy, limit} = require("firebase/firestore");

const test_all_polls_ref = collection(db, 'test_all_polls');
const test_queue_ref = collection(db, 'test_queue');
const user_ref = collection(db, 'user');

async function storePoll(aPoll){   
    try {
        let docRef = await addDoc(test_all_polls_ref,aPoll);
        return await docRef.id;
      } catch (error) {
        // Handle the error
        console.error('Error:', error);
      }
  }

  async function verifyPoll(docId){   
    //get full poll data with document ID

    try {
        const documentRef = await doc(db, "test_all_polls", docId);
        const documentSnapshot = await getDoc(documentRef);
        if (documentSnapshot.exists()) {
          //grab from all polls
          const documentData = documentSnapshot.data();
          console.log("Document data:", documentData);
          //write to test_queue
          await addDoc(test_queue_ref,documentData);
          //delete from all polls
          await deleteDoc(documentRef)
          return {status: "success", creator_id: documentSnapshot.data().creator_id}
        } else {
          console.log("Document not found");
            return {status: "fail", creator_id: ""}
        }
      } catch (error) {
        console.error("Error getting document:", error);
        return {status: "fail", creator_id: ""}
      }
  }

  async function denyPoll(docId){
    try {
      const documentRef = await doc(db, "test_all_polls", docId);
      const documentSnapshot = await getDoc(documentRef);
      if (documentSnapshot.exists()) {
        //delete from all polls
        await deleteDoc(documentRef)
        return {status: "success", creator_id: documentSnapshot.data().creator_id}
      } else {
        console.log("Document not found");
        return {status: "fail", creator_id: ""}
      }
    } catch (error) {
      console.error("Error getting document:", error);
      return {status: "fail", creator_id: ""}
    }
  }






async function preparePost() {
    try {
        const to_post = [];
        // Query the collection, order by the created_at field in ascending order, and limit to 2 documents
        const q = query(test_queue_ref, orderBy("created_at"), limit(3));
        const querySnapshot = await getDocs(q);

        // Loop through the documents and push data to the array
        querySnapshot.forEach(  (aDoc) => {
            to_post.push(aDoc.data());
            //delete from test_queue ⚠
            const documentRef =  doc(test_queue_ref, `${aDoc.id}`);
            //delete from test_queue
             deleteDoc(documentRef)
        });
        return to_post;
    } catch (error) {
        console.error("Error retrieving documents:", error);
        // Rethrow the error to handle it further if needed
        throw error;
    }
}

  async function updateUserPolls(message_id, poll_name, creator_id){
    //search user's document by id
      // update the polls field
      const documentRef = doc(user_ref, `${creator_id}`);
        // Get the current document data
      const documentSnapshot = await getDoc(documentRef);
      if (documentSnapshot.exists()) {
          const my_polls = documentSnapshot.data().my_polls;

          //cut string if more than 22 chx
          if(poll_name.length > 25)
            poll_name = poll_name.slice(0,25)+'...'
          // Add a new element to the my_polls array
          let new_poll = [...my_polls, {quest: poll_name,message_id}];
          try {
              // Update the document with the new my_polls array
              await updateDoc(doc(db, "user", `${creator_id}`), { my_polls: new_poll });
              console.log('Document successfully updated with new poll.');
          } catch (error) {
              console.error('Error updating document:', error);
          }
      }

  }

  async  function userAuth(user_data){
    let user_name = user_data.first_name;
      try {
          const documentRef = await doc(db, "user", `${user_data.id}`);
          const documentSnapshot = await getDoc(documentRef);
          if (documentSnapshot.exists()) {
              const documentData = documentSnapshot.data();
              user_name = documentData.first_name;
              return user_name;
          } else {
              try {
                  await setDoc(documentRef, {first_name: user_data.first_name, username: user_data.username, my_polls: [], subscriptions: []});
                  console.log('Document successfully written with the specific ID.');
              } catch (error) {
                  console.error('Error writing document:', error);
              }
          }
      } catch (error) {
          console.error("Error getting document:", error);
      }

      return user_name;
  }
async function getUserPolls(userId){
    try {
        const documentRef = await doc(db, "user", `${userId}`);
        const documentSnapshot = await getDoc(documentRef);
        if (documentSnapshot.exists()) {
            //delete from all polls
            return documentSnapshot.data().my_polls;
        } else {
            console.log("Document not found");
            return [];
        }
    } catch (error) {
        console.error("Error getting document:", error);
        return [];
    }

}

async function getSubscriberIds(tag){
    try {
        const documentRef = await doc(db, "subscriptionData", tag);
        const documentSnapshot = await getDoc(documentRef);
        if (documentSnapshot.exists()) {
            //delete from all polls
            return documentSnapshot.data().ids;
        } else {
            console.log("Document not found");
            return [];
        }
    } catch (error) {
        console.error("Error getting document:", error);
        return [];
    }
}


async function getSubscriptions(userId){
    console.log(userId)
    try {
        const documentRef = await doc(db, "user", `${userId}`);
        const documentSnapshot = await getDoc(documentRef);
        if (documentSnapshot.exists()) {
            //delete from all polls
            return documentSnapshot.data().subscriptions;
        } else {
            console.log("Document not found");
            return [];
        }
    } catch (error) {
        console.error("Error getting document:", error);
        return [];
    }
}

async function manageSub(userId, tag){
    console.log(userId, tag)

    let userSubs = await getSubscriptions(userId);
    if(userSubs.includes(tag)){
        //un subscribe
        // delete from ids array of tag document
    /// 😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁
        // Fetch the Firestore document with the array field
        const tagRef = doc(db, 'subscriptionData', tag);
        const docSnap = await getDoc(tagRef);
        if (docSnap.exists()) {
            const data = docSnap.data();
            let ids = data.ids;
            // Add a new element to the answers array
            ids.splice(ids.indexOf(userId),1);
            try {
                let new_ids = [...ids];
                await updateDoc(tagRef, { ids: new_ids });
                // update user sub
                const userRef = doc(db, 'user', `${userId}`);
                try {
                    const new_subs = userSubs.filter(sub => sub !== tag);
                    await updateDoc(userRef, { subscriptions: new_subs});
                    return {status: "success", message: `unsubscribed from ${tag}`}
                } catch (error) {
                    console.error('Error updating document:', error);
                    // TODO: revert above update❤️
                    return {status: "fail", message: "Error updating document"}
                }

            } catch (error) {
                console.error('Error updating document:', error);
            }
        }
        //🎆🎆🎆🎆🎆🎆🎆🎆🎆🎆🎆🎆🎆🎆🎆🎆🎆🎆😁👎✅✅✅
    }else{
        if(userSubs.length >= 3){
            console.log("Only 3 allowed")
            return { status: "fail", message: "only 3 subs allowed max"}
        }else{
            // subscribe
            // -- update my subs array
            // Fetch the Firestore document with the array field
            const tagRef = doc(db, 'subscriptionData', tag);
            const docSnap = await getDoc(tagRef);
            if (docSnap.exists()) {
                const data = docSnap.data();
                const ids = data.ids;
                // Add a new element to the ids array
                try {
                    let new_ids = [...ids, userId];
                    await updateDoc(tagRef, { ids: new_ids });
                    const userRef = doc(db, 'user', `${userId}`);
                    try {
                        let new_subs = [...userSubs, tag];
                        await updateDoc(userRef, { subscriptions: new_subs});
                        return {status: "success", message: "subscription added"};
                    } catch (error) {
                        console.error('Error updating document:', error);
                        // TODO: remove from the tags ids array ❤️ *revert update
                        return {status: "fail", message: "Error updating document"}
                    }
            }catch (e){
                    console.error("Document not found", e)
                    return {status:"fail", message: "Document not found"}
                }
            }else{
                console.error("Tag document not found");
                return {status: "fail", message: "error locating tag data"}
            }




        }

    }


}

module.exports ={storePoll,verifyPoll,denyPoll,preparePost,userAuth,updateUserPolls, getUserPolls, getSubscriberIds, getSubscriptions, manageSub}








